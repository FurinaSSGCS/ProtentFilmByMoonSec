package com.davemorrissey.labs.subscaleview.provider

interface InputProvider
