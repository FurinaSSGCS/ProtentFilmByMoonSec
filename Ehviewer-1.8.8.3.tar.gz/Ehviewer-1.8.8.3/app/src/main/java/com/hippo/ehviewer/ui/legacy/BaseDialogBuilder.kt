package com.hippo.ehviewer.ui.legacy

import android.content.Context
import com.google.android.material.dialog.MaterialAlertDialogBuilder

open class BaseDialogBuilder constructor(
    context: Context,
) : MaterialAlertDialogBuilder(context)
